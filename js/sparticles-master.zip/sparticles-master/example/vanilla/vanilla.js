
(function() {

  window.onload = function() {
    var $main = document.querySelector("main");
    window.mySparticles = new Sparticles($main);
  }

}());
